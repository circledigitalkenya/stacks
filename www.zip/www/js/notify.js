

// device APIs are available
//
// Wait for Cordova to load
//
document.addEventListener("deviceready", onDeviceReady, false);

// Cordova is ready
//
function onDeviceReady() {
    console.log("RRRRRRRRRRRRRRRRRRRRRRRRR");
    $('.main-window').css('background','yellow');
}