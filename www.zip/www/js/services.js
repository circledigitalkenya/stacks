angular.module('ladders.services', [])
